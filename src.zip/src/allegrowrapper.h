#ifndef ALLEGRO_WRAPPER_H
#define ALLEGRO_WRAPPER_H

#include <allegro.h>

#define ALLEGRO_KEY_END KEY_END
#define ALLEGRO_KEY_MAX KEY_MAX
#define ALLEGRO_KEY_F(n) KEY_F(n)
#define ALLEGRO_GETCH() readkey()

#endif // ALLEGRO_WRAPPER_H
