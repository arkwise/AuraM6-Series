#ifndef PDCURSES_WRAPPER_H
#define PDCURSES_WRAPPER_H

#include <pdcurses/curses.h>

#define clear pdc_clear
#define hline pdc_hline
#define vline pdc_vline


#endif // PDCURSES_WRAPPER_H
